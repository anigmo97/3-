#!/usr/bin/octave -qf

load("videosTr.gz");
c=0; i0=find(data(:,end)==c);
data0=data(i0,1:end-1);
n0=rows(data0);
mu0=sum(data0)/n0;
cov0=(data0-repmat(mu0,n0,1))'*(data0-repmat(mu0,n0,1))/n0;


c=1; i1=find(data(:,end)==c);
data1=data(i1,1:end-1);
n1=rows(data1);
mu1=sum(data1)/n1;
cov1=(data1-repmat(mu1,n1,1))'*(data1-repmat(mu1,n1,1))/n1;

mus(i0,:)=repmat(mu0,n0,1);
mus(i1,:)=repmat(mu1,n1,1);

covs(i0,:)=repmat(diag(cov0)',n0,1);
covs(i1,:)=repmat(diag(cov1)',n1,1);

data=[(data(:,1:end-1)-mus)./covs data(:,end)];
