function cstar=linmachv2(w,x)
  g=x*w;
  [maxc,argmaxc]=max(g');
  cstar=argmaxc';
endfunction
