# #!/usr/bin/octave -qf
# printf("\n1) Producto escalar de los vectores v1 = (1, 3, 8, 9) y v2 = (−1, 8, 2, −3)\n");
# v1 = [ 1 3 8 9];
# v2 = [-1 8 2 -3];

# producto_escalar = sum(v1 .* v2) 

# printf("\n2a) Obtén la matriz de dimensiones4 × 4 a partir del producto de los vectores v1 y v2 \n")

# # Version 1

# M1 = v1(1) * v2;
# M2 = v1(2) * v2;
# M3 = v1(3) * v2;
# M4 = v1(4) * v2;

# M = [M1;M2;M3;M4]

# #Version 2
# s=[]; for i=v1 s=[s;v2*i]; end; s

# printf("\n2b) Calcula su determinante\n")
# determinante_M = det(M)

# printf("\n2c) Calcula sus valores propios\n")
# valores_propios = eig(M)

# printf("\n3a)Calcula su submatriz2 × 2 formadas por las las 1 y 3 y las columnas 2 y 3\n")
# submatriz = M([1,3],[2,3])

# printf("\n3b)Súmale la matriz todo unos a la submatriz resultante\n")
# M_suma = submatriz + ones(2,2)

# printf("\n3c) Calcula el determinante de la matriz resultante.\n")
# det_M_suma = det(M_suma)

# printf("\n3d) Calcula la inversa de la matriz resultante.\n")
# inv_M_suma= inv(M_suma)

# printf("\n4a) Calcula su máximo valor y su posición (de 3d).\n")
# [vMaximos,VposMaximos]=max(inv_M_suma);
# [maxValor,columna] = max(vMaximos)
# indice = find(vMaximos==maxValor);
# fila = VposMaximos(indice)

# printf("\n4b) Calcula las posiciones fila y columna) de los elementos mayores que 0.(de 3d).\n")
# [filas,columnas]= size(inv_M_suma);
# #inv_M_suma([1],:)
# x=1;
# posiciones=[];
# while (x <= filas)
# v = inv_M_suma([x],:);
# posMayoresQue0 = find(v>0);
# for i=posMayoresQue0 posiciones=[posiciones;[x,i]]; end;
# x++;
# endwhile
# posiciones;

# printf("\n Posiciones de los valores mayores que 0: \nFila  Columna\n")
# posiciones

# printf("\n4c) Calcula Calcula la suma de cada columna\n")
# sum(inv_M_suma)

# printf("\n4d) Calcula Calcula la suma de cada columna\n")
# sum(inv_M_suma,2)

# printf("\n5) Salva la matriz inversa resultante del ejercicio 3 con hasta 7 dígitos decimales;comprueba que se ha guardado correctamente")
# save_precision(7)
# save "inv.dat" inv_M_suma

# printf("\n6) Define una función Octave que reciba una matriz y devuelva la primera fila y la primera columna de esa matriz")
# function [primera_fila,primera_columna] = damePrimeraFilaYColumna(matriz) primera_fila= matriz([1],:); primera_columna=matriz(:,[1]); end

# [fila,columna] = damePrimeraFilaYColumna([1 2;3 4])

# #Ejercicio 7
