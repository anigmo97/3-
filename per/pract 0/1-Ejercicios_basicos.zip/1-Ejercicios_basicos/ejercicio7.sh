#!/usr/bin/octave -qf
nomFich=input('Escriba el nombre del fichero: ',"s")
load nomFich
transpuesta = inv_M_suma'
save "tras.dat" traspuesta
