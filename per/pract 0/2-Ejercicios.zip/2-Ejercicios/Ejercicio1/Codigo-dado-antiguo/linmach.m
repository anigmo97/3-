# retornamos cstar
# nombre Funcion linmach
# toma dos parametros
function cstar=linmach(w,x) # w -> vector de pesos de las clases  x-> vector pesos objeto 
  C=columns(w); # C -> numero de columnas == numero de clases
  cstar=1; # inicializamos la columna elegida a 1 (la primera)
  max=-inf; # inicializamos maximo a - inf
  for c=1:C # por cada clase
    g=w(:,c)'*x; # g = vectorDePesosClase * vectorPesosMuestra
    if (g>max) # Si g es mayor que el maximo
    max=g;     # max = g 
    cstar=c;   # la columna (clase) = c
    endif; end
endfunction
