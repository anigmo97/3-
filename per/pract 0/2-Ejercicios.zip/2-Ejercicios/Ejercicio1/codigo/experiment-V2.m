#!/usr/bin/octave -qf
load("OCR_14x14.gz"); %carga el archivo que le pases
[N,L]=size(data); % N => numero Filas  L=> numero Columnas
D=L-1; % D => Columnas - 1 (En la ultima te dice la clase )
ll=unique(data(:,L)); % ll -> valores distintos de la ultima columna (clases)					
C=numel(ll); % C => numero de valores distintos ( numero de clases )
rand("seed",23); % crea numero aleatorio con semilla 23 
data=data(randperm(N),:);% retorna un vector fila que contiene una permutación
							% aleatoria de las filas y columnas. (mezcla)
[w,E,k]=perceptron(data(1:round(.7*N),:));
		% w -> vectores de pesos de cada clase (matriz de pesos)
		% E -> numero de errores en la traza de perceptron
		% k -> numero de iteraciones realizadas para ajustar los vectores de pesos
		% si k == K no se pudieron ajustar antes de alcanzar el numero maximo de iteraciones
M=N-round(.7*N); % NTr => integer mas cercano a ( 0,7 * N) coge el 70% filas
te=data(N-M+1:N,:); % te = Array (datos entrenamiento)
tem=te(:,1:D)';
tem = [ones(1,M);tem];
rl= ll(linmach2(w,tem)); 
[nerr m]=confus(te(:,L),rl); % te da el numero de errores
		##calcula ite(%)

printf("\nNumero de errores cometidos %s\n\n\n",disp(nerr))