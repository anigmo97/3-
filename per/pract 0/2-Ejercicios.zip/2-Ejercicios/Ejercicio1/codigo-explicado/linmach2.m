function cstar=linmach2(w,x); # w -> vector de pesos de las clases  x-> Matriz formada por vectores de pesos objeto #retornamos cstar
 matriz_Valores= x'*w;
 # la multiplicacion matricial no es conmutativa y el la fila del primero por la columna del segundo
 [maximo_valor,indice]=max(matriz_Valores');
 cstar= indice';
endfunction
