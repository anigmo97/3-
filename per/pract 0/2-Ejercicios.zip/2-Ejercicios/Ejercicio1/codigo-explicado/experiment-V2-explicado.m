#!/usr/bin/octave -qf

load("OCR_14x14.gz"); %carga el archivo que le pases
printf("datos cargados = \n")
printf("Componente_1 Componente_2 Clase_Correcta \n")
disp (data)
input ("", "s");
[N,L]=size(data); % N => numero Filas  L=> numero Columnas
printf("\nCalculamos el numero de Filas y columnas...\n")
printf("\nFilas (numero de muestras) = ")
disp(N)
printf("Columnas  = ")
disp(L)
input ("", "s");
D=L-1; % D => Columnas - 1 (En la ultima te dice la clase )
printf("\nD = al numero de columnas menos 1 ( la ultima te dice la clase no es una componente del objeto)\nD=")
disp(D)
input ("", "s");
printf("\nEn ll guardaremos los valores distintos de la ultima columna ( las distintas clases)\n")
ll=unique(data(:,L)) % ll -> valores distintos de la ultima columna (clases)	
printf("\nEn C guardaremos el numero de valores distintos de la ultima columna (numero de  clases)\n")				
C=numel(ll) % C => numero de valores distintos ( numero de clases )
input ("", "s");
rand("seed",23); % crea numero aleatorio con semilla 23 
printf("\n Cambiamos de orden las filas \n");
data=data(randperm(N),:) % retorna un vector fila que contiene una permutación
% aleatoria de las filas y columnas. (mezcla)

printf("\nLlamamos a perceptron con el 70%s de las filas para calcular los vectores de pesos de las clases \n","%");
[w,E,k]=perceptron(data(1:round(.7*N),:));
		% w -> vectores de pesos de cada clase (matriz de pesos)
		% E -> numero de errores en la traza de perceptron
		% k -> numero de iteraciones realizadas para ajustar los vectores de pesos
		% si k == K no se pudieron ajustar antes de alcanzar el numero maximo de iteraciones
if(C==1) printf("\nClase 1\n")
else printf("\n   Clase_1   Clase_2   ...\n")
endif;
disp(w)
input ("", "s");
M=N-round(.7*N); % NTr => integer mas cercano a ( 0,7 * N) coge el 70% filas
printf("\n Ahora obtenemos el 30%s restante de los datos\n","%")
te=data(N-M+1:N,:); % te = Array (datos entrenamiento)
disp(te)
input ("", "s");
#printf("Creamos una columna con la misma longitud que el 30%s de los datos para guardar el resultado de la clase a la que creemos pertenecen\n","%")
#rl=zeros(M,1); % creamos un vector de zeros con 0,3Filas y 1 columna
#disp(rl)
# MODIFICAR
printf("\nPara calcular la clase, no debemos saberla, asique la eliminamos y transponemos los datos a analizar...\n")
input ("", "s");
if(C==1) printf("   Muestra_1  \n")
else printf("   Muestra_1  Muestra_2   ....\n")
endif;
tem=te(:,1:D)';
disp(tem)
printf("\nPara normalizar las muestras, hay que añadir un 1 delante de cada una \n")
tem = [ones(1,M);tem]
printf("\nAhora, llamamos a linmach con los vectores de pesos de las clases que nos dio perceptron y los vectores objeto a analizar...")
input ("", "s");
rl= ll(linmach2(w,tem));
printf("\nlinmach nos devuelve un vector con la clase a la que se ha calculado que deberia pertenecer cada objeto\n")
disp(rl)

#FIN MODIFICAR
[nerr m]=confus(te(:,L),rl); % te da el numero de errores
		##calcula ite(%)
printf("\nNumero de errores cometidos %s\n\n\n",disp(nerr))